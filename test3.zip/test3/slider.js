function check()
{
    var m=document.getElementsByClassName("box_xont");
    console.log(m);
}